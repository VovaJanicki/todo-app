countries = []

while True:
    country = input("Enter the country: ")
    countries.append(country.upper())
    print(countries)