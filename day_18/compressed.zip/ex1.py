while True:
    name = input("Enter your name: ")
    print(name.capitalize())